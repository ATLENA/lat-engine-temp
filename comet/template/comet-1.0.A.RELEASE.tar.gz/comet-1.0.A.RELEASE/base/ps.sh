#!/bin/sh

SCRIPTPATH=`cd $(dirname $0) ; pwd -P`
SCRIPT=$SCRIPTPATH/$(basename $0)

. ${SCRIPTPATH}/env.sh

if [ "`uname -s`" = "HP-UX" ]; then
	ps -efx | grep "zodiac.name=${INSTANCE_ID}" | grep "$ZODIAC_HOME/" | grep -v grep
else
	ps -ef | grep "zodiac.name=${INSTANCE_ID}" | grep "$ZODIAC_HOME/" | grep -v grep
fi
