#!/bin/sh

## Base Environment
export JAVA_HOME=/engn001/java/1.6.0u45_64
export LAT_HOME=/engn001/lat/1.0
export ENGN_VERSION="1.0.0.A.RELEASE"
export ENGN_HOME="${LAT_HOME}/engines/comet/comet-${ENGN_VERSION}"
export COMET_HOME=/engn001/lat/1.0/tm-servers/tm-server1
export INSTANCE_ID=tm-server1
export RUN_USER=tomcat
export LENA_LOG_HOME=${LENA_HOME}/logs
export DATE=`date +%Y%m%d`
export LOG_OUTPUT=file

## ZODIAC  Environment
export PATH=${PATH}:.
export INSTALL_PATH=${COMET_HOME}
export LOG_HOME=${INSTALL_PATH}/logs
export DUMP_HOME=${LOG_HOME}
export LOG_MAX_DAYS=0
export ZODIAC_OUT=${LOG_HOME}/lena-${INSTANCE_ID}-${DATE}.log
export ZODIAC_CONF=${COMET_HOME}/conf/session.conf
export ZODIAC_PRIMARY_PORT=`cat $ZODIAC_CONF | grep primary.port | cut -d '=' -f2`
export START_CLASS=zodiac.server.Main

JAVA_OPTS=" ${JAVA_OPTS} -Xmx1024m -XX:MaxMetaspaceSize=256m"
JAVA_OPTS=" ${JAVA_OPTS} -XX:+HeapDumpOnOutOfMemoryError"
JAVA_OPTS=" ${JAVA_OPTS} -XX:HeapDumpPath=${DUMP_HOME}/hdump"
JAVA_OPTS=" ${JAVA_OPTS} -Dzodiac.name=${INSTANCE_ID} -Dzodiac.logdir=${LOG_HOME}"
JAVA_OPTS=" ${JAVA_OPTS} -Dzodiac.home=${COMET_HOME} -Dzodiac.config=${ZODIAC_CONF}"
JAVA_OPTS=" ${JAVA_OPTS} -Dlog.output=${LOG_OUTPUT}"

export JAVA_OPTS

setup_classpath() {

  list=`ls ${ENGN_HOME}/server-lib/$1*.jar`
  for i in `echo $list`
  do
    LIB_CLASSPATH=$LIB_CLASSPATH:$i
  done

  export CLASSPATH=${LIB_CLASSPATH}

}

print_server_info () {

  echo "--------------------------------"
  if [ "$1" = "start" ] ; then
    echo "     Start Session Server       "
  elif [ "$1" = "starting" ] ; then
    echo "     Starting Session Server       "
  elif [ "$1" = "stop" ] ; then
    echo "     Stop Session Server       "
  fi
  echo "--------------------------------"
  echo "Using LAT_HOME   : $LAT_HOME"
  echo "Using ENGN_HOME : $ENGN_HOME"
  echo "Using COMET_HOME : $COMET_HOME"
  echo "Using INSTANCE_ID   : $INSTANCE_ID"
  echo "Using SERVICE_PORT : $ZODIAC_PRIMARY_PORT"
  echo "Using JAVA_HOME   : $JAVA_HOME"
#  echo "Using CLASSPATH :   $CLASSPATH"
  echo
  if [ "$1" = "start" ] ; then
    echo "Session Server Started.."
  elif [ "$1" = "stop" ] ; then
    echo "Session Server Stopped.."
  fi
  echo

}
