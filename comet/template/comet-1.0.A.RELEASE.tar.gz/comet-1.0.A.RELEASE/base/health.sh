#!/bin/bash
MSG=`sh /usr/local/lena/servers/sessionServer/console.sh status`
FAIL="##### sessionServer is not running. exiting.. #####"
if [ "$MSG" != "$FAIL" ]; then exit 0; else exit 1; fi
