#!/bin/sh

SCRIPTPATH=`cd $(dirname $0) ; pwd -P`
SCRIPT=$SCRIPTPATH/$(basename $0)

. ${SCRIPTPATH}/env.sh
setup_classpath lena-session

RUNNER=`whoami`

show_help(){

  echo "------------------------------------------------------------"
  echo "-  Usage: ./console.sh <COMMAND>                           -"
  echo "-  <COMMAND> is one of the following:                      -"
  echo "-  1. was_list                                            -"
  echo "-  2. status                                               -"
  echo "-  3. was_serverq                                          -"
  echo "-  4. was_sync                                             -"
  echo "-     It needs WAS ID                                      -"
  echo "-     example: ./console.sh was_sync <was id>              -"
  echo "-  5. search                                               -"
  echo "-     It needs SESSION ID.                                 -"
  echo "-     example: ./console.sh search <session id>            -"
  echo "-  6. dump (print session id)                              -"
  echo "------------------------------------------------------------"
}

if [ ${RUNNER} != $RUN_USER ] ;
   then echo "Deny Access - User: ${RUNNER}. Not $RUN_USER" ;
   exit 0 ;
fi

if [ "`uname -s`" = "HP-UX" ]; then
	ZODIAC_PS=`ps -efx | grep "zodiac.name=${INSTANCE_ID}" | grep "${CLASSPATH}" | grep -v grep`
else
	ZODIAC_PS=`ps -ef | grep "zodiac.name=${INSTANCE_ID}" | grep "${CLASSPATH}" | grep -v grep`
fi

if [ "${ZODIAC_PS}" = "" ] ;
    then echo "##### ${INSTANCE_ID} is not running. exiting.. #####";
    exit 0;
fi

PID=`echo ${ZODIAC_PS} | awk {'print $2'} `

echo "=====zodiac session server JMX Console====="

if [ "$#" = "0" ]; then
   show_help
else
	SCRIPTPATH=`cd $(dirname $0) ; pwd -P`
	SCRIPT=$SCRIPTPATH/$(basename $0)
   . ${SCRIPTPATH}/env.sh
   setup_classpath lena-session

   CLASSPATH=.:${CLASSPATH}:${JAVA_HOME}/lib/tools.jar

   mbean_name="";
   mbean_opt="";
   flag="false";

    case $1 in
        "was_list")
                mbean_name="Zodiac:type=ServerQ,name=tomcat";
                mbean_opt="getServerInfo";
                flag="true";
        ;;
        "status")
                mbean_name="Zodiac:type=Monitor,name=monitor";
                mbean_opt="getStatusString";
                flag="true";
        ;;
        "was_serverq")
                mbean_name="Zodiac:type=ServerQ,name=tomcat";
                flag="true";
        ;;
        "was_sync")
        		mbean_name="Zodiac:type=ServerQ,name=tomcat";
        		mbean_opt="serverSync";
        		flag="true";
        ;;
        "search")
        		mbean_name="Zodiac:type=ServerQ,name=tomcat";
        		mbean_opt="search";
        		flag="true";
        ;;
        "dump")
        		mbean_name="Zodiac:type=MainEntry,name=entry";
        		mbean_opt="printSessionAll";
        		flag="true";
        ;;
        *) show_help
    esac

	if [ $flag = "true" ]; then
	    if [ "$mbean_opt" != '' ]; then
	    	if [ "$#" = "2" ]; then
	        	${JAVA_HOME}/bin/java ${JAVA_OPTS} -cp .:${CLASSPATH} zodiac.mbean.JMXClient $PID $mbean_name $mbean_opt $2
	        else
	        	${JAVA_HOME}/bin/java ${JAVA_OPTS} -cp .:${CLASSPATH} zodiac.mbean.JMXClient $PID $mbean_name $mbean_opt
	        fi
	    else
	        ${JAVA_HOME}/bin/java ${JAVA_OPTS} -cp .:${CLASSPATH} zodiac.mbean.JMXClient $PID $mbean_name
	    fi
	    echo ""
	fi


fi
