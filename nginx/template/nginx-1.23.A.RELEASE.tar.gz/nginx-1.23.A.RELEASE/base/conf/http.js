function hello(request) {
	request.return(200, "Hello world!");
}

export default {hello};
